/******************************************************************************
 * dummy_operations.h
 * *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 * Christian Schulz <christian.schulz.phone@gmail.com>
 *****************************************************************************/


#ifndef DUMMY_OPERATIONS_UVZ6V6T7
#define DUMMY_OPERATIONS_UVZ6V6T7

class dummy_operations {
public:
        dummy_operations();
        virtual ~dummy_operations();

        void run_collective_dummy_operations();
};


#endif /* end of include guard: DUMMY_OPERATIONS_UVZ6V6T7 */
