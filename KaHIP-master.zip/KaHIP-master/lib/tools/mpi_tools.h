/******************************************************************************
 * mpi_tools.h 
 * *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 * Christian Schulz <christian.schulz.phone@gmail.com>
 *****************************************************************************/

#ifndef MPI_TOOLS_HMESDXF2
#define MPI_TOOLS_HMESDXF2


class mpi_tools {
public:
        mpi_tools();
        virtual ~mpi_tools();

        //static void non_active_wait_for_root();
};


#endif /* end of include guard: MPI_TOOLS_HMESDXF2 */
