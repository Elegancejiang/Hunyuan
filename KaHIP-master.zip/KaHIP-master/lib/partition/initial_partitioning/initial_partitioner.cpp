/******************************************************************************
 * initial_partitioner.cpp 
 * *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 * Christian Schulz <christian.schulz.phone@gmail.com>
 *****************************************************************************/

#include "initial_partitioner.h"

initial_partitioner::initial_partitioner() {
                
}

initial_partitioner::~initial_partitioner() {
                
}

